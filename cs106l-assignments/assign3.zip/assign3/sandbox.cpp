#include "class.h"
/*
 * CS106L Assignment 3: Make a Class
 * Created by Fabio Ibanez with modifications by Jacob Roberts-Baca.
 */

void sandbox() {
  // STUDENT TODO: Construct an instance of your class!
  Player Soberham("Kevin");
}